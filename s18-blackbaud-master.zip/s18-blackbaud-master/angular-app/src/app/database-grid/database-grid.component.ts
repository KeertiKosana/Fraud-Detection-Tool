import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-database-grid',
  templateUrl: './database-grid.component.html',
  styleUrls: ['./database-grid.component.css']
})
export class DatabaseGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
