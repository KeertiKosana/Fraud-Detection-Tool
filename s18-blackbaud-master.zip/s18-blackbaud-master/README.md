# S18_Blackbaud

Files relevant to blackbaud fraudulent activity project.

## AngularD3

UI starting template to eventually display fraudulent activity results using Angularjs and D3js.

## R

Tool to visualize database values
