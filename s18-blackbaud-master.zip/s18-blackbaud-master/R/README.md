# R shiny app to visualize transaction data trends

Simple tool to visualize transaction data. The app is currently selecting data from the GL7Transactions table and plotting the 'amount' for the selected per user.

## Installing

 Using sqljdbc4.jar driver to connect to db. This may need to be downloaded and placed in the appropriate directory.


## Running

```
runApp('proto')
```

